<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | MadhavTechInfo</title>
    <link href="https://madhavtechinfo.000webhostapp.com/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://madhavtechinfo.000webhostapp.com/assets/css/style.css" rel="stylesheet">
</head>

<body>

    <section class="login py-50 position-relatve overflow-hidden d-flex align-items-center justify-content-center">
        <!-- <div class="login-img">
            <img src="https://www.justdrive.co.in/assets/images/login-bg.jpg" alt="" class="w-100 h-100">
        </div> -->

        <div class="container">
            <div class="rounded-4 p-4 shadow">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="col-5">
                        <h2 class="fs-1 text-web-secondary ff-third mb-3">Log In</h2>
                        <p class="text-gray fs-14 fw-medium mb-3">new here? 
                            <a href="javascript:void(0)" class="text-web-secondary text-decoration-none">Sign Up</a>
                        </p>
                        <form>
                            <div class="mb-3">
                                <label for="" class="main-lable">Email/Mobile No *</label>
                                <input type="text" class="form-control"
                                    placeholder="Enter Email id / 10 Digit mobile number">
                            </div>
                            <div class="mb-3">
                                <label for="" class="main-lable">Password *</label>
                                <input type="text" class="form-control" placeholder="Password">
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">
                                    Remember me
                                </label>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="col-4">
                                    <button class="btn-web-secondary w-100">Login</button>
                                </div>
                                <a href="javascript:void(0)" class="text-dark">Forgot Your Password?</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

    </section>



    <script src="https://madhavtechinfo.000webhostapp.com/assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>