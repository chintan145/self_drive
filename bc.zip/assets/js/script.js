/////// script

// back-to-top & header
if (window.matchMedia('(min-width: 768px)').matches) {   
    $(window).scroll(function () {
        if ($(this).scrollTop() > 500) {
            $("header").css("transform", "translateY(-56px)translateX(-50%)");
            $(".back-to-top").css("transform", "translateY(0px)");
        }
        else {
            $("header").css("transform", "translateY(-0px)translateX(-50%)");
            $(".back-to-top").css("transform", "translateY(100px)");
        }
    });
}

$(".back-to-top").click(function () {
    $("html,body").animate({
        scrollTop: 0,
    }, 1000);
});

// testimonial
$('.testimonial .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    mouseDrag: false,
    animateOut: 'fadeOut',
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});

// google review
$('.gr .owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    mouseDrag: false,
    animateOut: 'fadeOut',
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 2
        }
    }
})